import React, { Component} from 'react';
import { Text, View, StyleSheet,TouchableOpacity } from 'react-native';

class App extends Component {
  state = {
       count: 0 
  }
onPress = () => {
  this.setState({
    count: this.state.count +  1
  })
}
render () {
  return ( 
    <View style={styles.container}>
      <TouchableOpacity  style={styles.button}   onPress={this.onPress}  >
       <Text>click me</Text>
       </TouchableOpacity>
        <View>
          <Text>You clicked { this.state.count} </Text>
        </View>
        </View>
       )  
    }
  }

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: "center"
  },
  button: {
    alignitens : "center",
    backgroundColor: "#DDDDDD",
    padding: 1,
    marginBottom: 10,
  },
  });
export default App;